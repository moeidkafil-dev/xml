# سند جامع محصول (Super PRD) + سوپر پرامپت تولید کد
## سیستم ارکستراسیون چندعامله‌ی مبتنی بر LLM محلی (Local Multi-Agent Orchestration System)

> این سند مستقیماً از روی دیاگرام `pdf_-__excel.graphml` که آپلود کردی استخراج شده. تمام گروه‌ها (tools / top frame local llm / ceo agent / memory / top frame with api / top view / input top view) و همه‌ی یال‌ها (edge) بررسی و به مشخصات فنی تبدیل شدند. جایی که دیاگرام ابهام داشت (مثلاً نام‌های `contaxt manager`, `schduler`, `desecion system`, `bash ruuner`) تصمیم مهندسی گرفتم و در متن مشخص کردم.
>
> **تصمیم‌های تأییدشده توسط تو:** این پروژه (`agentos`) کاملاً جدا و مستقل از پروژه‌ی قبلی «حسابدار» است (پروژه‌ی جدید). مدل پیش‌فرض Ollama همان `gemma2` است. از همان فاز اول باید هم CLI کامل و هم یک وب UI/UX کامل داشته باشد (نه فقط API خام).

---

## بخش ۱ — نگاه کلی محصول

**نام کاری پروژه:** `agentos` (قابل تغییر)

**یک‌خطی:** یک سیستم چندعامله‌ی صددرصد پایتونی که پرامپت کاربر + فایل‌های کاربر (بخصوص PDF) را می‌گیرد، از طریق یک عامل مدیرکل (CEO Agent) برنامه‌ریزی، تخصیص ابزار، اجرای ابزار و ارزیابی نتیجه انجام می‌دهد، همه‌چیز را در یک سیستم حافظه‌ی چندلایه ثبت می‌کند و می‌تواند بین یک **LLM محلی (Ollama)** یا یک **API بیرونی** سوییچ کند — با یک لایه‌ی «تصمیم» که بین این دو مسیر انتخاب می‌کند.

**چرا این پروژه:** خودکارسازی کارهایی که نیاز به «فهمیدن یک ورودی (پرامپت/PDF) → تولید یک قطعه اجرایی (bash/vbs/xml/python) → اجرا → بررسی نتیجه → گزارش» دارند، با قابلیت یادگیری/حافظه بین اجراها (نه فقط یک session بی‌حافظه).

**اصول طراحی:**
1. **صددرصد پایتون** — هیچ زبان دیگری در runtime پروژه نباشد (تولید اسکریپت bash/vbs/xml مجاز است چون *خروجی* تولیدشده است، نه بخشی از سورس پروژه).
2. **LLM Provider agnostic** — یک اینترفیس یکسان برای Ollama (محلی) و هر API بیرونی (Anthropic/OpenAI/...)، با یک `decision_system` که بر اساس context تصمیم می‌گیرد کدام Provider را صدا بزند.
3. **Traceable memory** — هر تصمیم و هر خروجی باید قابل ردیابی در حافظه و لاگ باشد (چون در دیاگرام `logger`, `result`, `human access` مستقیماً به `memory` وصل‌اند).
4. **Tool dispatch، نه pipeline خطی** — در دیاگرام، تولیدکننده‌های bash/vbs/xml/python پشت‌سرهم رسم شده‌اند، ولی از نظر مهندسی این‌ها ۶ ابزار مستقل‌اند که «مدیر ابزار» (tool manager) بسته به نوع تسک یکی را انتخاب می‌کند، نه یک زنجیره‌ی اجباری. این تصمیم را در PRD رسمی کردم.
5. **Human-in-the-loop اختیاری** — گره‌ی `human access` یعنی یک نقطه‌ی بازبینی/دخالت انسانی روی حافظه، باید به‌صورت optional (approve/override) پیاده شود، نه اجباری در مسیر خودکار.

---

## بخش ۲ — نگاشت دقیق دیاگرام → معماری

### ۲.۱ جریان اصلی (از گروه `top frame(local llm)` + `top view`)

```
user prompt ────┐
                 ├──> prompt analyser ──┐
users files ─────┼──> pdf parser ───────┼──> context manager ──┬──> decision system ──> CEO Agent (محلی)
                 │                      │                      └──> outer API path (اگر تصمیم=API)
                 │                      └──────────────────────────> memory (context هر بار لاگ می‌شود)
                 │
CEO Agent ──> result maker ──> logger ──> result ──> CEO Agent (بازخورد/چرخه)
                 │                              └──> memory
human access ──> memory   (بازبینی/تزریق دستی انسان به حافظه)
decision system ──> user prompt   (در صورت نیاز به شفاف‌سازی، برمی‌گردد و از کاربر می‌پرسد)
```

**نکته‌ی طراحی مهم:** در دیاگرام `top view`، `decision system` هم از `context manager` ورودی می‌گیرد و هم می‌تواند به `user prompt` برگردد. این را به‌عنوان **حلقه‌ی روشن‌سازی (clarification loop)** پیاده می‌کنیم: اگر context manager تشخیص دهد اطلاعات ناقص است، decision system یک سؤال برمی‌گرداند به کاربر به‌جای اجرای کور.

### ۲.۲ CEO Agent (گروه `ceo agent`)

مسئولیت: دریافت context تحلیل‌شده، برنامه‌ریزی، تخصیص ابزار، اجرا، و ارزیابی — با یک **حلقه‌ی خوداصلاحی**.

نگاشت گره‌ها:

| گره در دیاگرام | نقش در کد |
|---|---|
| `prompt analyser` | تحلیل نیت (intent) پرامپت ورودی به CEO |
| `llm` | فراخوانی مدل (از طریق provider abstraction) |
| `planner` | تولید نقشه‌ی گام‌به‌گام از تسک |
| `schduler` (Scheduler) | ترتیب/زمان‌بندی اجرای گام‌ها (صف اجرا) |
| `hidden memory` | scratchpad موقتِ داخلی CEO (short-lived, در RAM/SQLite temp) — جدا از حافظه‌ی بلندمدت اصلی |
| `tool manager` | انتخاب ابزار مناسب از Tool Registry |
| `tool executer` | اجرای واقعی ابزار (subprocess sandboxed) |
| `forecast` | پیش‌بینی ریسک/نتیجه‌ی محتمل قبل و بعد از اجرا (از `llm` و از `result analyser` هر دو ورودی می‌گیرد — یعنی یک حلقه‌ی پیش‌بینی/بازبینی) |
| `result analyser` | ارزیابی خروجی واقعی در برابر پیش‌بینی؛ اگر رد شد → برمی‌گردد به `llm` یا `forecast` برای تلاش مجدد |
| `result` | خروجی نهایی که به بیرون (`result maker`) می‌رود |

**حلقه‌ی کنترل کیفیت:** `tool executer → result analyser → (اگر ناموفق: forecast یا llm) → planner دوباره`. این باید در کد به‌صورت **حداکثر N بار retry** پیاده شود (پیشنهاد: `max_retries=3` قابل‌تنظیم) تا حلقه‌ی بی‌نهایت رخ ندهد — دقیقاً همان چیزی که قبلاً گفته بودی می‌خواهی ازش دور بمونی.

### ۲.۳ لایه‌ی ابزار (گروه `tools`)

۶ ابزار مستقل، همه پشت یک Tool Registry:

| ابزار | ورودی | خروجی | نکته امنیتی |
|---|---|---|---|
| Bash Command Maker | تسک زبان‌طبیعی | رشته‌ی دستور bash | باید از یک allow-list دستورات عبور کند |
| VBS Command Maker | تسک | اسکریپت `.vbs` | فقط اگر هدف Windows-automation باشد؛ روی Kali صرفاً تولید می‌شود نه اجرا (اجرا نیاز به wine/Windows دارد) |
| XML File Maker | داده‌ی ساخت‌یافته | فایل XML (شامل OOXML برای Excel — این همان پل «PDF→Excel» است) | validation با schema قبل از نوشتن روی دیسک |
| Python Script Maker | تسک | فایل `.py` | باید در sandbox (venv/subprocess با timeout) اجرا شود |
| Python File Runner | مسیر فایل `.py` | stdout/stderr/exit code | timeout اجباری + resource limit |
| Bash Runner | رشته‌ی دستور | stdout/stderr/exit code | timeout اجباری + بدون `sudo`/دسترسی root به‌صورت پیش‌فرض |

> **ارتباط با نام فایل آپلودی (`pdf_-__excel`):** به‌احتمال زیاد usecase اول همین است — PDF ورودی پارس می‌شود، داده استخراج می‌شود، و از طریق **XML File Maker** یک خروجی Excel (`.xlsx` که داخلش OOXML/XML است) یا از طریق **Python Script Maker + Runner** (با `openpyxl`) ساخته می‌شود. پیشنهاد من: مسیر `openpyxl` (پایتون خالص) را اول پیاده کنید، چون قابل تست و صددرصد پایتونی است؛ مسیر XML خام را به‌عنوان fallback/گزینه‌ی پیشرفته نگه دارید.

### ۲.۴ سیستم حافظه (گروه `memory`)

دیاگرام ۲۷ نوع حافظه را به‌صورت یک زنجیره‌ی خطی رسم کرده (Sensory → Working → STM → LTM → Episodic → Semantic → Procedural → Goal → Task → Context → Conversation → Tool → Environment/World State → User Profile → Learning → Experience → Failure → Success → Reflection → Planning → RAG → Cache → Shared → Agent Local → Audit/History → Temporal → Meta) که یک `memory manager agent` آن را تغذیه می‌کند.

**تصمیم مهندسی (مهم):** ساخت ۲۷ زیرسیستم واقعاً جدا از هم over-engineering و کند است. پیشنهاد عملی:

- یک **Unified Memory Store** (SQLite برای structured/relational + یک vector store سبک مثل `chromadb` یا `sqlite-vec` برای RAG/Semantic) با یک ستون/فیلد `memory_type` که مقدارش یکی از همان ۲۷ enum است.
- هر رکورد: `{id, memory_type, content, embedding?, ttl, importance, source_agent, created_at, tags}`.
- زنجیره‌ی دیاگرام را به‌صورت **pipeline پردازشی** (نه ۲۷ کلاس جدا) پیاده می‌کنیم: ورودی خام از `Sensory` شروع می‌شود، بعد از فیلتر/summarize به `Working/STM` می‌رود، و «ترفیع» (promotion) به `LTM` وقتی اتفاق می‌افتد که `memory manager agent` تشخیص دهد اطلاعات مهم/تکرارشونده است.
- این طراحی همان تاکسونومی دیاگرام را حفظ می‌کند ولی قابل build و تست در یک sprint است.

**گروه `memory manager` (pipeline پاکسازی/نگهداری):**

```
input reader → input analyser → input setter in memory → memory analyser →
memory complete analyser → find junks (تشخیص داده‌ی زائد/تکراری) →
tables cleaner → memory analyser → sleep mode (idle/batch maintenance) →
output request analyser → result maker → result/log
```

این پایپ‌لاین یک **job نگهداری دوره‌ای** است (مثل GC حافظه) — پیشنهاد: با `APScheduler` یا یک cron داخلی هر N دقیقه/بعد از هر M تعامل اجرا شود، نه synchronous روی هر request.

### ۲.۵ مسیر API بیرونی (گروه `top frame(with api)`) و Decision System

ساختار تقریباً یکسان با مسیر local llm است، با این تفاوت که `ceo` با `outer api / input from api` جایگزین می‌شود، و مستقیماً `forecast`/`result analyser` را هم دارد (بدون CEO داخلی کامل). یعنی مسیر API یک **مسیر سبک‌تر** است برای وقتی سیستم تصمیم می‌گیرد کار را به یک مدل بیرونی بسپارد (مثلاً برای تسک‌های سنگین‌تر از ظرفیت مدل محلی).

`decision system` (در `top view`) بین این دو مسیر انتخاب می‌کند. چون در دیاگرام قانون مشخص نشده بود، این پیش‌فرض را انتخاب کردم (قابل تغییر در config، بدون نیاز به تغییر کد):
- معیار پیش‌فرض: طول/پیچیدگی context (تعداد توکن) بالاتر از آستانه‌ی قابل‌تنظیم (پیش‌فرض `8000` توکن) → مسیر API
- نوع تسک نیازمند دانش به‌روز/اینترنتی → API
- در غیر این صورت → local llm (پیش‌فرض اصلی، برای حفظ حریم خصوصی و هزینه‌ی صفر)
- همیشه قابل override دستی توسط کاربر از طریق CLI flag یا سوییچ در وب UI (`force_local` / `force_api`)

### ۲.۶ `input top view` — نمونه‌ی usecase PDF→نتیجه

این زیرگراف ساده‌ترین نسخه‌ی pipeline است: دو ورودی PDF + دو ورودی user prompt → `pdf parser` (دو نمونه) → `agent` واحد → `result file`. این را به‌عنوان **integration test اصلی پروژه** در نظر می‌گیریم: «۲ فایل PDF + ۱ پرامپت کاربر بده، یک result file (مثلاً Excel) بگیر».

---

## بخش ۳ — پشته‌ی فنی (Tech Stack)

| لایه | انتخاب | دلیل |
|---|---|---|
| زبان | Python 3.11+ | الزام صریح تو |
| LLM محلی | Ollama (سازگار با gemma2 که قبلاً استفاده کرده بودی) از طریق `ollama-python` یا HTTP API خام | زیرساخت موجودت |
| LLM بیرونی | Anthropic SDK (یا OpenAI-compatible) پشت یک اینترفیس مشترک | انعطاف |
| Structured memory | SQLite (`sqlite3`/`sqlmodel`) | صفر-وابستگی، فایل‌محور، مناسب local |
| Vector/RAG memory | `chromadb` (embedded, پایتونی) | صددرصد پایتون، بدون نیاز به سرویس جدا |
| PDF parsing | `pypdf` + `pdfplumber` (برای جدول‌ها) | پوشش متن + جدول |
| Excel output | `openpyxl` | صددرصد پایتون، بدون وابستگی به Excel نصب‌شده |
| Sandboxed exec | `subprocess` با `resource`/`timeout` + (اختیاری) `firejail` در سطح سیستم | امنیت اجرای کد تولیدشده |
| Scheduler (memory maintenance) | `APScheduler` | سبک، پایتونی |
| API layer | FastAPI | backend اصلی برای CLI و وب هر دو |
| Web UI | **NiceGUI** (اولویت اول) یا Streamlit (fallback ساده‌تر) | صددرصد پایتون، بدون نیاز به نوشتن JS/React جدا، ولی UX کامل‌تر و interactive‌تر از Streamlit |
| CLI | `typer` | CLI مدرن با auto-help، سازگار با همون core logic که وب UI هم استفاده می‌کند |
| Config | `pydantic-settings` + `.env` | type-safe config |
| Test | `pytest` + `pytest-asyncio` | استاندارد |
| Logging | `structlog` یا `logging` استاندارد + JSON lines روی دیسک | قابل پارس برای `logger→result`/`memory` |

---

## بخش ۴ — ساختار پیشنهادی پروژه

```
agentos/
├── pyproject.toml
├── README.md
├── .env.example
├── src/agentos/
│   ├── __init__.py
│   ├── config.py
│   ├── core/
│   │   ├── llm_provider.py        # اینترفیس مشترک local(Ollama)/API
│   │   ├── decision_system.py     # انتخاب مسیر local/api + clarification loop
│   │   └── context_manager.py
│   ├── input/
│   │   ├── prompt_analyser.py
│   │   └── pdf_parser.py
│   ├── ceo/
│   │   ├── ceo_agent.py
│   │   ├── planner.py
│   │   ├── scheduler.py
│   │   ├── hidden_memory.py
│   │   ├── forecast.py
│   │   └── result_analyser.py
│   ├── tools/
│   │   ├── registry.py            # Tool Manager + Tool Executer
│   │   ├── bash_tool.py
│   │   ├── vbs_tool.py
│   │   ├── xml_tool.py
│   │   ├── python_script_tool.py
│   │   └── sandbox.py             # timeout/resource limits مشترک
│   ├── memory/
│   │   ├── store.py                # Unified Memory Store (SQLite + Chroma)
│   │   ├── types.py                # Enum با ۲۷ نوع حافظه
│   │   ├── manager_pipeline.py     # input_reader→...→result/log
│   │   └── maintenance.py          # find_junks / tables_cleaner / sleep_mode job
│   ├── output/
│   │   ├── result_maker.py
│   │   ├── excel_writer.py         # openpyxl wrapper
│   │   └── logger.py
│   ├── human/
│   │   └── human_access.py         # approve/override hook روی memory؛ هم CLI هم وب UI صداش می‌زنن
│   ├── api/
│   │   ├── server.py                # FastAPI — لایه‌ی مشترک بین CLI و وب UI
│   │   └── routes/
│   │       ├── tasks.py             # ایجاد/وضعیت/نتیجه‌ی تسک
│   │       ├── memory.py            # مرور/جست‌وجو/approve حافظه
│   │       └── files.py             # آپلود PDF / دانلود خروجی Excel
│   ├── web/
│   │   ├── app.py                   # اپ NiceGUI — داشبورد، فرم آپلود، مرور حافظه، تأیید انسانی
│   │   └── pages/
│   │       ├── dashboard.py
│   │       ├── chat.py              # چت با CEO Agent
│   │       ├── memory_browser.py
│   │       └── settings.py          # سوییچ local/API، انتخاب مدل
│   └── cli/
│       └── main.py                  # دستورات typer: run, chat, memory, serve
├── tests/
│   ├── unit/
│   └── integration/
│       └── test_pdf_to_excel_e2e.py
└── scripts/
    └── run_cli.py
```

---

## بخش ۵ — فازبندی (Roadmap)

**فاز ۰ — اسکلت + دو رابط از روز اول:** config, llm_provider (فقط Ollama/gemma2), context_manager, prompt_analyser, logging به فایل، **یک FastAPI حداقلی (`/health`, `/chat`)** و **یک صفحه‌ی NiceGUI حداقلی (چت ساده به مدل)**، به‌علاوه یک دستور `typer` (`agentos chat`). تست: هم از CLI هم از وب، پرامپت ساده بده، جواب از مدل محلی بگیر و لاگ شود.

**فاز ۱ — حافظه‌ی پایه:** `memory/store.py` (فقط SQLite، بدون vector هنوز)، `types.py` + یک صفحه‌ی وب `memory_browser` حداقلی برای دیدن رکوردها. تست: نوشتن/خواندن رکورد با memory_type مشخص، هم از API هم از UI قابل مشاهده باشد.

**فاز ۲ — CEO Agent حداقلی:** planner → scheduler → llm → result، بدون tool واقعی (فقط echo tool)؛ در وب یک صفحه‌ی `dashboard` که وضعیت تسک زنده را نشان دهد. تست: یک تسک ساده را planner به ۲-۳ گام بشکند و در UI قابل رصد باشد.

**فاز ۳ — Tool Layer:** bash_tool + python_script_tool + sandbox (چون این دو پرکاربردترین‌اند)؛ vbs_tool و xml_tool در فاز بعد. تست: CEO یک اسکریپت پایتون بسازد، اجرا کند، خروجی بگیرد؛ خروجی در UI/CLI نمایش داده شود.

**فاز ۴ — PDF→Excel usecase (`input top view`):** pdf_parser + excel_writer + یک `agent` ساده + **آپلود PDF از صفحه‌ی وب و دانلود خروجی Excel از همان‌جا**. این integration test اصلی پروژه است.

**فاز ۵ — Forecast/Result-Analyser + retry loop:** حلقه‌ی خوداصلاحی با `max_retries`، وضعیت retry در UI نمایش داده شود (نه فقط لاگ خام).

**فاز ۶ — Decision System + مسیر API:** llm_provider دوم (API)، معیار انتخاب (آستانه‌ی توکن + override دستی)، حلقه‌ی clarification؛ سوییچ local/API و انتخاب مدل در صفحه‌ی `settings` وب UI.

**فاز ۷ — Memory Manager Pipeline + maintenance job:** پاکسازی دوره‌ای، ترفیع STM→LTM.

**فاز ۸ — Human Access کامل (approve/override از UI) + Vector/RAG memory + XML/VBS tools + سخت‌سازی امنیتی + پرداخت نهایی UX (استایل، احراز هویت ساده اگر لازم شد).**

> چون از فاز ۰ هم CLI و هم وب لازم است، هر دو باید روی همان core logic (`ceo/`, `tools/`, `memory/`) سوار باشند و منطق تکراری نداشته باشند — API/FastAPI مرز مشترک است.

---

## بخش ۶ — معیار پذیرش کلی (Acceptance Criteria)

- [ ] `pytest` سبز روی تمام تست‌های unit + حداقل یک integration test کامل (PDF→Excel)
- [ ] هیچ subprocess بدون timeout اجرا نمی‌شود
- [ ] هر تصمیم CEO (tool انتخاب‌شده، خروجی، نتیجه‌ی result_analyser) یک رکورد در memory/log دارد
- [ ] سوییچ local↔API با یک متغیر config کار می‌کند بدون تغییر کد
- [ ] retry loop حداکثر N بار، بعدش fail واضح با پیام قابل‌فهم (نه سکوت/تعلیق بی‌نهایت)
- [ ] پروژه با `pip install -e .` و یک `README` قابل اجرا روی Kali Linux باشد
- [ ] هم CLI (`agentos ...`) و هم وب UI (`agentos serve` → NiceGUI روی FastAPI) از فاز ۰ کار می‌کنند و هر دو از همان core logic استفاده می‌کنند (بدون duplicate شدن منطق)
- [ ] وب UI شامل حداقل: چت با CEO Agent، آپلود PDF/دانلود Excel، مرور حافظه، تنظیمات (local/API + مدل)

---

## بخش ۷ — سوپر پرامپت (برای دادن به مدل کدنویس/LLM محلی یا Claude Code)

> کل متن زیر را عیناً کپی کن و به عامل کدنویس بده. طوری نوشته شده که خودکفا (self-contained) باشد.

```
نقش تو: یک مهندس نرم‌افزار ارشد پایتون هستی که باید یک پروژه‌ی واقعی، اجراشونده و تست‌شده تحویل بدهد — نه توضیح مفهومی، نه pseudo-code.

هدف: ساخت پروژه‌ی «agentos» — یک پروژه‌ی کاملاً جدید و مستقل (بدون هیچ وابستگی به پروژه‌های قبلی) — یک سیستم ارکستراسیون چندعامله که پرامپت کاربر و فایل PDF را می‌گیرد، از طریق یک CEO Agent برنامه‌ریزی/اجرا/ارزیابی می‌کند، از ابزارهای تولید و اجرای اسکریپت (bash/python اول، بعد vbs/xml) استفاده می‌کند، نتیجه را در Excel یا متن گزارش می‌دهد، و همه‌چیز را در یک حافظه‌ی چندلایه‌ی SQLite (+ در فازهای بعد Chroma برای RAG) ثبت می‌کند. سیستم باید بتواند بین یک LLM محلی (Ollama، مدل پیش‌فرض `gemma2`) و یک API بیرونی سوییچ کند. از همان فاز اول باید هم یک CLI کامل (typer) و هم یک وب اپ کامل (NiceGUI روی FastAPI) داشته باشد — نه یکی به‌جای دیگری.

قیدهای سخت (غیرقابل‌مذاکره):
1. صددرصد پایتون ۳.۱۱+. هیچ وابستگی به زبان دیگری در runtime سرور نباشد (frontend هم چون NiceGUI است پایتونی می‌ماند، بدون نوشتن دستی JS/React). تولید فایل bash/vbs/xml به‌عنوان *خروجی* مجاز است، نه بخشی از سورس اجرایی پروژه.
2. هر اجرای subprocess باید timeout و مدیریت خطای صریح داشته باشد؛ هرگز اجرای بی‌نهایت یا بدون سقف نباشد.
3. هر حلقه‌ی retry/خوداصلاحی (forecast ↔ result_analyser ↔ llm) باید یک `max_retries` قابل‌تنظیم داشته باشد (پیش‌فرض ۳) و بعد از آن fail صریح بدهد.
4. اینترفیس LLM باید abstract باشد (`LLMProvider`) با حداقل دو پیاده‌سازی: `OllamaProvider` (پیش‌فرض `gemma2`) و `APIProvider` (Anthropic-compatible)، انتخاب‌شونده از config بدون تغییر کد بقیه‌ی سیستم. معیار سوییچ خودکار: طول context بالاتر از آستانه‌ی قابل‌تنظیم (پیش‌فرض ۸۰۰۰ توکن) → API، وگرنه local؛ همیشه با override دستی از CLI/وب.
5. CLI و وب UI هرگز نباید منطق تکراری داشته باشند — هر دو باید از همان لایه‌ی `api/` (FastAPI) و core logic استفاده کنند.
6. کد باید type-hint کامل داشته باشد، با `pydantic`/`pydantic-settings` برای config و مدل‌های داده.
7. هر ماژول باید حداقل یک تست unit داشته باشد؛ پروژه باید یک integration test کامل PDF→Excel داشته باشد (و در حد امکان یک smoke test برای endpointهای FastAPI).
8. هیچ کلید API یا secret هارد-کد نشود؛ همه از `.env`/`pydantic-settings`.
9. خروجی نهایی باید شامل: کد کامل پروژه، `pyproject.toml` معتبر، `README.md` با دستورات نصب/اجرا/تست (هم `agentos serve` برای وب هم `agentos chat` برای CLI)، و `.env.example`.

ساختار پروژه (رعایت دقیق مسیرها):
[در این‌جا دقیقاً همان درخت پوشه‌ی بخش ۴ این سند را کپی کن]

معماری منطقی که باید پیاده‌سازی شود (خلاصه، جزئیات کامل در PRD پیوست‌شده):
- Input: user_prompt + PDF(s) → prompt_analyser + pdf_parser → context_manager
- context_manager → decision_system → (local: CEO Agent) یا (api: مسیر سبک API)
- CEO Agent: planner → scheduler → llm → forecast ↔ result_analyser (حلقه) → tool_manager → tool_executer(sandboxed) → result
- Tools (مستقل، از طریق Tool Registry، نه زنجیره‌ی اجباری): bash_tool, python_script_tool (فاز اول)؛ vbs_tool, xml_tool (فاز بعد)
- Memory: Unified Store در SQLite با فیلد memory_type (enum طبق پیوست) + پایپ‌لاین نگهداری (input_reader→...→sleep_mode→...→result/log) به‌صورت job دوره‌ای با APScheduler
- Output: result_maker → excel_writer (openpyxl) + logger (JSON lines) → result
- Human Access: هوک approve/override روی memory، هم از CLI هم از یک صفحه‌ی وب (کامل می‌شود در فاز آخر)
- Web/CLI: از فاز ۰ به بعد، هر فاز باید یک نسخه‌ی حداقلی/به‌روزشده هم در CLI (typer) و هم در وب (NiceGUI) داشته باشد، هر دو از طریق FastAPI با core logic صحبت می‌کنند

ترتیب ساخت (دقیقاً به همین ترتیب پیش برو، هر فاز باید تست سبز داشته باشد قبل از فاز بعد):
فاز ۰: اسکلت پروژه + config + OllamaProvider(gemma2) + logging + FastAPI حداقلی (/health,/chat) + CLI (`agentos chat`) + صفحه‌ی وب ساده‌ی چت (NiceGUI)
فاز ۱: memory/store.py + types.py (SQLite) + صفحه‌ی وب memory_browser حداقلی
فاز ۲: CEO Agent حداقلی (planner→scheduler→llm→result) با echo tool + صفحه‌ی dashboard وضعیت تسک
فاز ۳: bash_tool + python_script_tool + sandbox با timeout
فاز ۴: pdf_parser + excel_writer + یک agent ساده PDF→Excel + integration test + آپلود/دانلود از صفحه‌ی وب
فاز ۵: forecast + result_analyser + retry loop + نمایش وضعیت retry در UI
فاز ۶: APIProvider + decision_system (آستانه‌ی توکن + override) + clarification loop + صفحه‌ی settings برای سوییچ local/API
فاز ۷: memory manager pipeline + maintenance job دوره‌ای
فاز ۸: human_access کامل (approve/override از وب) + vbs_tool + xml_tool + سخت‌سازی امنیتی sandbox + جلا دادن UX نهایی

قوانین کیفیت:
- بعد از هر فاز، خروجی pytest را نشان بده (سبز باشد) قبل از رفتن به فاز بعد.
- اگر برای پیاده‌سازی یک بخش ابهام هست، به‌جای توقف/سؤال بی‌پایان، ساده‌ترین تصمیم مهندسی معقول را بگیر، در کامنت/README بنویس چرا، و ادامه بده.
- از حلقه‌های تصمیم‌گیری بی‌پایان یا رفت‌وبرگشت بین فازها خودداری کن — هر فاز باید در یک پاس تمام و قابل تست باشد.
- در پایان، یک README شامل «چطور Ollama را وصل کنم»، «چطور API provider را عوض کنم»، «چطور تست integration را اجرا کنم» بنویس.

اکنون فاز ۰ را شروع کن و کد کامل آن را بده.
```

---

## بخش ۸ — وضعیت تصمیم‌ها

| سؤال | تصمیم نهایی |
|---|---|
| رابطه با «حسابدار» | پروژه‌ی کاملاً جدا و مستقل |
| مدل Ollama پیش‌فرض | `gemma2` |
| رابط کاربری | CLI کامل (typer) + وب UI/UX کامل (NiceGUI روی FastAPI) از فاز ۰ |
| آستانه‌ی تصمیم local↔API | ۸۰۰۰ توکن context، پیش‌فرض قابل‌تغییر در config، همیشه قابل override دستی |
| شکل `human access` | approve/override هم از CLI هم از یک صفحه‌ی وب اختصاصی (کامل در فاز ۸) |

همه‌ی ابهامات اصلی رفع شده. این سند (PRD کامل + سوپر پرامپت بخش ۷) آماده‌ی کپی به یک عامل کدنویس (Claude Code / هر LLM محلی یا API دیگر) است تا فاز ۰ را همین حالا بسازد.
